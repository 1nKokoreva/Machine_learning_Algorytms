
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Wprowadz liczbe najblizszych sasiadow, \n" +
                           "ktorych program powinnen wrocic: ");
        int k = scanner.nextInt();

        KnnAlgorytm knn = new KnnAlgorytm(k);
        knn.nazwaTestPoint();

    }
}
