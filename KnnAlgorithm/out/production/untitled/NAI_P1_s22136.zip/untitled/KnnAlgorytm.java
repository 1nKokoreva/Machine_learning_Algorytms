import java.util.*;
import java.util.stream.Collectors;

public class KnnAlgorytm {
    int k;

    public KnnAlgorytm(int k) {
        this.k = k;
    }

    public String predictClass(ClassWrapper testPoint, List<ClassWrapper> classWrappersTrain) {

        for (int i = 0; i < classWrappersTrain.size(); i++) {
            ClassWrapper trainRecord = classWrappersTrain.get(i); //liniejka w train
            double lenght = ClassWrapper.odlegloscDwoch(testPoint, trainRecord);
            trainRecord.setLenght(lenght);
        }

        Collections.sort(classWrappersTrain, new Comparator<ClassWrapper>() {
            @Override
            public int compare(ClassWrapper o1, ClassWrapper o2) {
                double x = o1.getLenght() - o2.getLenght();
                if (x == 0) {
                    return 0;
                } else if (o1.getLenght() > o2.getLenght()) {
                    return 1;
                } else {
                    return -1;
                }
            }
        });
        List<ClassWrapper> kElements = classWrappersTrain.subList(0, k); //zwraca k pierwszych elementow z listy classWraper
        LinkedHashMap<String, Integer> classCountMap = new LinkedHashMap<>();

        for (ClassWrapper w : kElements) {
            Integer classCount = classCountMap.get(w.getClassName());
            if (classCount != null) {
                classCount += 1;
                classCountMap.put(w.getClassName(), classCount);
            } else {
                classCountMap.put(w.getClassName(), 1);
            }

        }

        // metoda sort ktora odpowiada za sorotwanie elementow w strumieniu
        // ale musi wiedziec na jakiej podstawie ma sortowac pary wartosci {klucz:wartosc}
        // my informujemy funkcj sorted poprzez przekazanie jej lambdy(Map.Entry.comparingByValue())
        // i dzieki temu informujemy ze sortujemy nasze elementy bazujac na wartoscach
        String className = classCountMap.entrySet()

                .stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("");

        return className;
    }

    public void nazwaTestPoint() {
        ReadClasses readClasses = new ReadClasses("train.txt", "test.txt");

        List<ClassWrapper> testPoints = readClasses.getClassWrapperTest();
        List<ClassWrapper> trainPoints = readClasses.getClassWrapperTrain();
        double testPointsCount = testPoints.size();
        double correctCount = 0;
        for (int i = 0; i < testPoints.size(); i++) { //zwraca etykiety dla dannego testpointa
            String predictedClass = predictClass(testPoints.get(i), trainPoints);
            if (predictedClass.equals(testPoints.get(i).getClassName())) {
                correctCount += 1;
            }
            ClassWrapper testPoint = testPoints.get(i);
            System.out.println(Arrays.toString(testPoint.getVector()) + " " + testPoint.getClassName() + " predicted: " + predictedClass);
        }
        System.out.println("Dokladnosc: " + (int) ((correctCount / testPointsCount) * 100) + "%");

    }

}

